<?php

namespace App\Exceptions;

use Exception;

class TripPaymentRequestException extends Exception
{
    //
}
