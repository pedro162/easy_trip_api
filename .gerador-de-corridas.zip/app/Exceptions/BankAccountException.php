<?php

namespace App\Exceptions;

use Exception;

class BankAccountException extends Exception
{
    //
}
