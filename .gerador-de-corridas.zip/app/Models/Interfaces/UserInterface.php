<?php 

namespace App\Models\Interfaces;

interface UserInterface{
}
